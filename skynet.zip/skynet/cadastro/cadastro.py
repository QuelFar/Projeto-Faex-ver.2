import PySimpleGUI as sg
import pymysql
pymysql.install_as_MySQLdb()
import mysql.connector

    
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  database="gestao_pc"
)


def login():
    sg.theme('Reddit')
    coluna = [
        [
            sg.Text('Usuário :',pad=(5,0)),
            sg.Input(key='user',size=(15,1),background_color='white',text_color='black')
        ],
        [
            sg.Text('Senha :  ',pad=(5,0)),
            sg.Input(key ='pass',password_char="*",size=(15,1),background_color='white',text_color='black')
        ]
    ]
    layout_login = [
        [
            sg.Image(filename="login.png"),
            sg.Column(coluna)
        ],
        [
            sg.Button('Entrar',key='entrar')
        ]
    ]
    return sg.Window('LOGIN CADASTRO DE PC',layout_login,finalize=True)

def cadastro():
    sg.theme('Reddit')
    layout = [
        [
            sg.Text('CADASTRO - COMPUTADORES',pad=(100,0),font='Cooper 18')
        ],
        [sg.Text("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬")],
        [
            sg.Text('Marca',pad=(5,0)),
            sg.Input(key='marca',size=(15,1),background_color='white',text_color='black')
        ],
        [
            sg.Text('Modelo',pad=(5,0)),
            sg.Input(key='modelo',size=(15,1),background_color='white',text_color='black')
        ],
        [sg.Text("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬")],
        [
            sg.Text('Placa mãe',pad=(5,0)),
            sg.Input(key='placa_mae',size=(15,1),background_color='white',text_color='black')
        ],
        [
            sg.Text('Processador',pad=(5,0)),
            sg.Input(key='processador',size=(15,1),background_color='white',text_color='black')
        ],
        [
            sg.Text('Memória RAM',pad=(5,0)),
            sg.Input(key='ram',size=(15,1),background_color='white',text_color='black')
        ],
        [
            sg.Text('Armazenamento',pad=(5,0)),
            sg.Input(key='hd',size=(15,1),background_color='white',text_color='black')
        ],
        [sg.Text("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬")],
        [
            sg.Text('Monitor',pad=(5,0)),
            sg.Input(key='marca_monitor',size=(15,1),background_color='white',text_color='black')
        ],
        [
            sg.Text('Modelo do monitor',pad=(5,0)),
            sg.Input(key='modelo_monitor',size=(15,1),background_color='white',text_color='black')
        ],
        [
            sg.Button('CADASTRAR',key='cadastrar')
        ]
    ]
    return sg.Window('CADASTRO COMPUTADORES',layout,finalize=True)

def banco():
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="gestao_pc"
    )
    mycursor = mydb.cursor()

    sql = "INSERT INTO desktop VALUES (null,%s,%s,%s,%s,%s,%s,default,%s,%s,null,null)"
    val = (f"{valor['marca']}",
        f"{valor['modelo']}",
        f"{valor['placa_mae']}",
        f"{valor['processador']}",
        f"{valor['ram']}",
        f"{valor['hd']}",
        f"{valor['marca_monitor']}",
        f"{valor['modelo_monitor']}"
        )

    mycursor.execute(sql, val)
    mydb.commit()


janela1, janela2 = login(), None

while True:
    window, evento, valor = sg.read_all_windows()
    if window == janela1 and evento == sg.WIN_CLOSED or window == janela2 and evento == sg.WIN_CLOSED:
        break
    if window == janela1 and evento == 'entrar':
        if valor['user'] == 'admin' and valor['pass'] == 'admin':
            janela1.hide()
            janela2 = cadastro()
        else:
            sg.popup("USUÁRIO NÃO CADASTRADO")
    if window == janela2 and evento == 'cadastrar':
        banco()
        sg.theme("DarkGreen2")
        sg.popup("CADASTRO SALVO COM SUCESSO")
        break