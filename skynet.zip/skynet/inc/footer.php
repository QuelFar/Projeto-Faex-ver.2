<?php
?>
<br><br><br><br>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
    <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 border-top fixed-bottom bg-dark">
            <div class="container">
                <p class="col-md-4 mb-0 text-light">&copy; Desenvolvido pela equipe SKYNET</p>
            </div>
    </footer>
</div>