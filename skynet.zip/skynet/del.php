<?php

require_once 'config.php';
require_once 'Crud.php';

$crud = new Crud(DB_HOST,DB_PORT,DB_NAME,DB_USER,DB_PASSWORD,DB_CHAR);
$dados = ['id' => $_GET['id']];
$select = $crud->delete('desktop',$dados['id']);
header('location: desktop.php');