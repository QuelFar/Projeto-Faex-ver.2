<?php

require_once 'config.php';
require_once HEADER_TEMPLATE;
require_once 'Crud.php';

$crud = new Crud(DB_HOST,DB_PORT,DB_NAME,DB_USER,DB_PASSWORD,DB_CHAR);
$dados = $_POST;
$select = $crud->select('desktop',$dados);
$select->fetch_assoc();


// desktop qtde de PC

?>
        <header>
            <div class="row">

                <div class="col-sm">
                    <h2>Desktops</h2>
                </div>
                <div class="col-sm-6 text-end h6">
                    <a class="btn btn-success" href="newdesktop.php">
                        <i class="bi bi-window-plus"></i> Novo Desktop
                    </a>
                    <a class="btn btn-secondary" href="">
                        <i class="bi bi-arrow-clockwise"></i> Atualizar
                    </a>
                </div>

            </div>
            <hr>
        </header>
        <table class="table">
            <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Marca</th>
                <th scope="col">Modelo</th>
                <th scope="col">Placa Mãe</th>
                <th scope="col">Processador</th>
                <th scope="col">Memória RAM</th>
                <th scope="col">Armazenamento</th>
                <th scope="col" class="text-end">Opções</th>
            </tr>
            </thead>
            <tbody class="table-group-divider">
            <?php
                if($select->num_rows > 0){
                    foreach ($select as $desktop){

                    ?>
                    <tr>
                        <td><?php echo $desktop['id'] ?></td>
                        <td><?php echo $desktop['marca'] ?></td>
                        <td><?php echo $desktop['modelo'] ?></td>
                        <td><?php echo $desktop['placa_mae'] ?></td>
                        <td><?php echo $desktop['processador'] ?></td>
                        <td><?php echo $desktop['ram'] ?></td>
                        <td><?php echo $desktop['hd'] ?></td>
                        <td class="text-end">
                            <a class="btn btn-sm btn-success" href="" data-bs-toggle="modal" data-bs-target="#exampleModal_<?php echo $desktop['id'] ?>">
                                <i class="bi bi-eye"></i>
                            </a>
                            <a class="btn btn-sm btn-warning" href="editdesktop.php?id=<?php echo $desktop['id'];?>">
                                <i class="bi bi-pencil-square"></i>
                            </a>
                            <a class="btn btn-sm btn-danger" href="del.php?id=<?php echo $desktop['id'];?>">
                                <i class="bi bi-trash"></i>
                            </a>

                        </td>
                    </tr>
                        <div class="modal fade" id="exampleModal_<?php echo $desktop['id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">ID : <?php echo $desktop['id'] ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body text-left">
                                        <ul class="list-group list-group-flush">

                                        </ul>
                                        <?php
                                        foreach ($desktop as $key => $value){
                                            echo "<li class='list-group-item'>$key : $value</li>";
                                        }

                                        ?>
                                        </ul>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
            <?php
                    }
                }else{
                    echo "
                    <tr>
                        <td colspan='4'>Nenhum registro encontrado.</td>
                    </tr>
                    ";
                }
                ?>
            </tbody>
        </table>
<?php

require_once FOOTER_TEMPLATE;


