<?php
require_once 'config.php';
require_once HEADER_TEMPLATE;

// substr(valor,  string inicia {0}, quantidade final {30} );

// modal bootstrap;

//href BASEURL;

?>
    <div class="p-4 p-md-5 mb-4 text-white rounded bg-dark">
        <div class="col-md-6 px-0">
            <h1 class="display-4 fst-italic">INSTITUIÇÃO SKYNET</h1>

        </div>
    </div>
    <div class="row mb-2">
        <div class="col-md-6">
            <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                <div class="col p-4 d-flex flex-column position-static">
                    <strong class="d-inline-block mb-2 text-primary">Desktop</strong>
                    <h3 class="mb-0">Visualizar computador</h3>
                    <p class="card-text mb-auto">Caso queira visualizar os computadores aperte no link abaixo.</p>
                    <a href="desktop.php" class="stretched-link">Visualizar...</a>
                </div>
                <div class="col-auto d-none d-lg-block">
                    <img src="images/micro.png">

                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                <div class="col p-4 d-flex flex-column position-static">
                    <strong class="d-inline-block mb-2 text-success">Sala</strong>
                    <h3 class="mb-0">Visualizar <br>Sala</h3>
                    <p class="mb-auto">Caso queira visualizar as salas aperte no link abaixo.</p>
                    <a href="sala.php" class="stretched-link">Visualizar...</a>
                </div>
                <div class="col-auto d-none d-lg-block">
                    <img src="images/ge-37-aula-informatica-conteudo-tecnologia.png">
                </div>
            </div>
        </div>
    </div>


<?php

require_once FOOTER_TEMPLATE;

?>