create SCHEMA gestao_pc;
USE  gestao_pc;

 CREATE TABLE pessoa(
	cpf varchar(18) PRIMARY KEY,
    nome varchar(30),
    telefone varchar(15),
    endereco varchar(100),
    email varchar(50),
    senha varchar(50),
    destino char(1), # P - PROFESSOR / A - ALUNO
    data_hora datetime    
);

CREATE TABLE sala(
	id int PRIMARY KEY auto_increment,
    graduacao varchar(100)
);

CREATE TABLE desktop(
	id int PRIMARY KEY auto_increment,
    marca varchar(30),
    modelo varchar(50),
    placa_mae varchar(50),
    processador varchar(50),
    ram varchar(50),
    hd varchar(50),
    estado_pc varchar(15) default 'Disponivel', # Disponivel ou Alocado
    marca_monitor varchar(50),
    modelo_monitor varchar(50),
    id_sala int,
    ra_aluno int,
    FOREIGN KEY (ra_aluno) REFERENCES Aluno(ra),
    FOREIGN KEY (id_sala) REFERENCES sala(id)
);

CREATE TABLE professor(
	id int PRIMARY KEY auto_increment,
    cpf_pessoa varchar(18),
    id_not varchar(30),
    marca_not varchar(50),
    modelo_not varchar(50),
    FOREIGN KEY (cpf_pessoa) REFERENCES pessoa(cpf)    
);

CREATE TABLE Aluno(
	ra int auto_increment primary key,
    cpf_pessoa varchar(18),
    id_sala int,
    FOREIGN KEY (cpf_pessoa) REFERENCES pessoa(cpf),
	FOREIGN KEY (id_sala) REFERENCES sala(id)
);

CREATE TABLE aula(
	id int primary key auto_increment,
    id_professor int,
    id_sala int,
    disciplina varchar(30),
    FOREIGN KEY (id_professor) REFERENCES professor(id),
    FOREIGN KEY (id_sala) REFERENCES sala(id)
);

			#CRIANDO USUARIO E PERMISSÃO BANCO GESTÃO#

create user 'pc_aluno'@'localhost' identified by '123aluno';
grant select on gestao_pc.aluno to 'pc_aluno'@'localhost';
grant select on gestao_pc.aula to 'pc_aluno'@'localhost';
grant select on gestao_pc.desktop to 'pc_aluno'@'localhost';
grant select on gestao_pc.professor to 'pc_aluno'@'localhost';
grant select on gestao_pc.sala to 'pc_aluno'@'localhost';
flush privileges;

create user 'pc_professor'@'localhost' identified by '123professor';
grant select,update on gestao_pc.aula to 'pc_professor'@'localhost';
grant select,update on gestao_pc.desktop to 'pc_professor'@'localhost';
grant select,update on gestao_pc.sala to 'pc_professor'@'localhost';
grant select on gestao_pc.aluno to 'pc_professor'@'localhost';
grant select on gestao_pc.pessoa to 'pc_professor'@'localhost';
grant select on gestao_pc.professor to 'pc_professor'@'localhost';
flush privileges;


DELIMITER $

CREATE trigger TRG_ATL_DESKTOP_ALUNO
after insert 
on Aluno
for each row
begin 
	declare id_pc int;
    
    set id_pc = (
    select id from desktop
	where desktop.id_sala = new.id_sala and 
    estado_pc = 'Disponivel' order by id asc limit 1);
                  
    update desktop set ra_aluno = new.ra where id = id_pc;
    update desktop set estado_pc = 'Alocado' where id = id_pc;
end$

DELIMITER ;

CREATE OR REPLACE VIEW vw_discricao_aluno AS
	Select a.ra, 
    p.nome , 
    s.graduacao, 
    d.id, 
    au.disciplina
from pessoa as p 
inner join aluno as a on a.cpf_pessoa = p.cpf
inner join sala as s on a.id_sala = s.id
inner join desktop as d on d.ra_aluno = a.ra
inner join aula as au on au.id_sala = s.id;


DELIMITER $
CREATE FUNCTION fnc_quantidade_pc_sala (par_id_sala int)
returns int deterministic
begin
	return 	(
    select count(id) AS quantidade_pc from desktop
	where id_sala = par_id_sala
    );
end$
DELIMITER ;

DELIMITER $
CREATE FUNCTION fnc_quantidade_pc_sala_ALOC (par_id_sala int)
returns int deterministic
begin
	return 	(
    select count(id) AS quantidade_pc from desktop
	where id_sala = par_id_sala
    and estado_pc = 'Alocado'
    );
end$
DELIMITER ;

DELIMITER $
CREATE PROCEDURE prd_Alterar_Desktop_AllDisponivel_Sala(
par_nome_graduacao varchar(30))
BEGIN
	declare par_id_sala int;
    
    set par_id_sala = (select id from sala where graduacao = par_nome_graduacao);
    
    update desktop set ra_aluno = null where id_sala = par_id_sala;
    update desktop set estado_pc = 'Disponivel' where id_sala = par_id_sala;
    
    
END$
DELIMITER ;