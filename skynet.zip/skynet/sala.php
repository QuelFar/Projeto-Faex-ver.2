<?php

require_once 'config.php';
require_once HEADER_TEMPLATE;

$crud = new Crud(DB_HOST,DB_PORT,DB_NAME,DB_USER,DB_PASSWORD,DB_CHAR);
$dados = $_POST;
$select = $crud->select('sala',$dados);
$select->fetch_assoc();

?>
<header>
    <div class="row">

        <div class="col-sm">
            <h2>Salas</h2>
        </div>
        <div class="col-sm-6 text-end h6">
            <a class="btn btn-success" href="newsala.php">
                <i class="bi bi-window-plus"></i> Nova Sala
            </a>
            <a class="btn btn-secondary "href="">
                <i class="bi bi-arrow-clockwise"></i> Atualizar
            </a>
        </div>

    </div>
    <hr>
</header>
<?php
if($select->num_rows > 0){
    foreach ($select as $sala){

        ?>
        <div class="card">
            <div class="card-header">
                <i class="bi bi-gear-fill"></i><?php echo $sala['id'] ?>
            </div>
            <div class="card-body">
                <h5 class="card-title"><?php echo $sala['graduacao'] ?></h5>
                <a href="#" class="btn btn-primary">Ver sala</a>
            </div>
        </div>
        <br>
        <?php
    }
}else{
    echo "
                    <tr>
                        <td colspan='4'>Nenhum registro encontrado.</td>
                    </tr>
                    ";
}
?>
<?php

require_once FOOTER_TEMPLATE;

?>
